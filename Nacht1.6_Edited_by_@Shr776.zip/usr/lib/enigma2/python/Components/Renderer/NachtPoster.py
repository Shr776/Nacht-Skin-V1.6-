# -*- coding: utf-8 -*-
# by digiteng...06.2020
# Python 3.13 port: 2026
# <widget source="session.Event_Now" render="NachtPoster" position="0,0" size="185,278" zPosition="1" />

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer, loadJPG
from urllib.request import urlopen
from urllib.parse import quote
import json
import re
import os

tmdb_api = "3c3efcf47c3577558812bb9d64019d65"

if not os.path.isdir("/tmp/poster"):
	os.makedirs("/tmp/poster")
path_folder = "/tmp/poster/"


class NachtPoster(Renderer):

	def __init__(self):
		Renderer.__init__(self)
		self.pstrNm = ''
		self.evntNm = ''
		self.srch = "multi"
		self.event = None
		self.timer = eTimer()
		try:
			self.timer.callback.append(self.showPoster)
		except (AttributeError, TypeError):
			self.timer.timeout.connect(self.showPoster)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
				self.filterSearch()
		except Exception:
			pass

	def showPoster(self):
		try:
			self.event = self.source.event
			if self.event:
				evnt = self.event.getEventName()
				evntN = re.sub(r"([\(\[]).*?([\)\]])|(: odc.\d+)|(\d+: odc.\d+)|(\d+ odc.\d+)|(:)|( -(.*?).*)|(,)|!", "", evnt)
				evntNm = evntN.replace("Die ", "The ").replace("Das ", "The ").replace("und ", "and ").replace("LOS ", "The ").rstrip()
				self.evntNm = evntNm
				pstrNm = path_folder + evntNm + ".jpg"
				if os.path.exists(pstrNm):
					self.instance.setPixmap(loadJPG(pstrNm))
					self.instance.setScale(1)
					self.instance.show()
				else:
					self.downloadPoster()
					self.instance.hide()
			else:
				self.instance.hide()
				return
		except Exception:
			pass

	def downloadPoster(self):
		try:
			url_tmdb = "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(self.srch, tmdb_api, quote(self.evntNm))
			response = urlopen(url_tmdb, timeout=10)
			data = response.read().decode('utf-8', 'ignore')
			results = json.loads(data).get('results', [])
			if results:
				poster = results[0].get('poster_path')
				if poster:
					url_poster = "https://image.tmdb.org/t/p/w185{}".format(poster)
					dwn_poster = path_folder + "{}.jpg".format(self.evntNm)
					img_response = urlopen(url_poster, timeout=10)
					img_data = img_response.read()
					with open(dwn_poster, 'wb') as f:
						f.write(img_data)
		except Exception:
			return

	def filterSearch(self):
		try:
			sd = self.event.getShortDescription() + "\n" + self.event.getExtendedDescription()
			w = [
				"serial",
				"series",
				"serie",
				"serien",
				"séries",
				"serious",
				"folge",
				"episodio",
				"episode",
				"ep.",
				"staffel",
				"soap",
				"doku",
				"tv",
				"talk",
				"show",
				"news",
				"factual",
				"entertainment",
				"telenovela",
				"dokumentation",
				"dokutainment",
				"documentary",
				"informercial",
				"information",
				"sitcom",
				"reality",
				"program",
				"magazine",
				"mittagsmagazin"
			]

			for i in w:
				if i in sd.lower():
					self.srch = "tv"
					break
				else:
					self.srch = "multi"

		except Exception:
			return

	def delay(self):
		try:
			if self.timer.isActive():
				self.timer.stop()
			self.timer.start(100, True)
		except Exception:
			pass