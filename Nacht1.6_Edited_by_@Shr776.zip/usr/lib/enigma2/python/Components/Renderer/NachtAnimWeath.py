# -*- coding: utf-8 -*-
# by digiteng...11.2020
# Python 3.13 port: 2026
# <widget render="NachtAnimWeath" path="/media/hdd/AnimatedWeatherPixmap/" position="75,215" size="128,128" source="session.MSNWeather" alphatest="blend" transparent="1" zPosition="9">
#   <convert type="MSNWeather">weathericon,current</convert>
# </widget>

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer
import os


class NachtAnimWeath(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		self.path = ""
		self.st = ""
		self.frame_index = 0
		self.list_size = 0
		self.frame_list = []
		self.anim_timer = eTimer()
		try:
			self.anim_timer.callback.append(self.animNext)
		except (AttributeError, TypeError):
			self.anim_timer.timeout.connect(self.animNext)

	def applySkin(self, desktop, screen):
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == "path":
				self.path = value
		self.skinAttributes = attribs
		ret = Renderer.applySkin(self, desktop, screen)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		if self.instance:
			st = ""
			if what[0] != self.CHANGED_CLEAR:
				try:
					st = self.source.iconfilename
					self.st = st.split("/")[-1].replace(".gif", "")
				except Exception:
					pass
				try:
					self.anim_timer.stop()
					self.frame_list = os.listdir(self.path + self.st)
					self.list_size = len(self.frame_list)
					if self.list_size > 0:
						self.frame_index = self.list_size
						self.anim_timer.start(100, False)
				except Exception:
					pass
			else:
				try:
					self.anim_timer.stop()
				except Exception:
					pass

	def animNext(self):
		try:
			if self.list_size <= 0:
				return
			self.frame_index -= 1
			if self.frame_index < 0:
				self.frame_index = self.list_size - 1
			frame_path = self.path + self.st + "/a{}.png".format(self.frame_index)
			if os.path.exists(frame_path):
				self.instance.setPixmapFromFile(frame_path)
				self.instance.setScale(1)
		except Exception:
			pass