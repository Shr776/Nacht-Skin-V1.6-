# -*- coding: utf-8 -*-
# PiconUni (RaedQuickSignal version)
# Copyright (c) 2boom 2012-15
# Python 3.13 port: 2026
#
# 26.09.2012 added search mountpoints
# 25.06.2013 added resize picon
# 26.11.2013 code optimization
# 02.12.2013 added compatibility with CaidInfo2 (SatName)
# 18.12.2013 added picon miltipath
# 27.12.2013 added picon reference
# 27.01.2014 added noscale parameter
# 28.01.2014 code optimization
# 02.04.2014 added iptv ref code
# 17.04.2014 added path in plugin dir
# 02.07.2014 small fix reference
# 09.01.2015 redesign code
# 17.08.2018 Update by mfraja to RAEDQuickSignal plugins
# 07.12.2018 Update by mfraja to RAEDQuickSignal plugins fix picon show on DreamOS
# 12.01.2022 Update by RAED to remove "sub-network" from namespace

from __future__ import absolute_import, print_function
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, ePicLoad
from Components.AVSwitch import AVSwitch
from Tools.Directories import fileExists, SCOPE_CURRENT_SKIN, SCOPE_PLUGINS, resolveFilename
from os import path as os_path
import os

try:
	from Components.Converter.Poll import PollConverter as Poll
	dreamos = True
except Exception:
	from Components.Converter.Poll import Poll
	dreamos = False


class RaedQuickSignalPiconUniShr(Renderer, Poll):
	__module__ = __name__

	if not os.path.exists("/usr/lib64"):
		searchPaths = (
			'/data/%s/',
			'/usr/lib/enigma2/python/Plugins/Extensions/%s/',
			'/media/hdd/%s/',
			'/media/ba/%s/',
			'/media/sda1/%s/',
			'/media/cf/%s/',
			'/media/sdb1/%s/',
			'/media/usb/%s/',
			'/media/sda/%s/',
			'/media/mmc/%s/',
			'/etc/%s/',
			'/usr/share/enigma2/%s/',
		)
	else:
		searchPaths = (
			'/data/%s/',
			'/usr/lib64/enigma2/python/Plugins/Extensions/%s/',
			'/media/hdd/%s/',
			'/media/ba/%s/',
			'/media/sda1/%s/',
			'/media/cf/%s/',
			'/media/sdb1/%s/',
			'/media/usb/%s/',
			'/media/sda/%s/',
			'/media/mmc/%s/',
			'/etc/%s/',
			'/usr/share/enigma2/%s/',
		)

	def __init__(self):
		Renderer.__init__(self)
		if dreamos:
			Poll.__init__(self, '')
		else:
			Poll.__init__(self)
		if os_path.exists('/data/piconpool'):
			self.path = 'piconpool'
		else:
			self.path = 'picon'
		self.scale = '0'
		self.nameCache = {}
		self.pngname = ''
		self.picon_default = "picon_default.png"
		self.picload = None

	def applySkin(self, desktop, parent):
		attribs = []
		for (attrib, value,) in self.skinAttributes:
			if attrib == 'path':
				self.path = value
			elif attrib == 'picon_default':
				self.picon_default = value
			else:
				attribs.append((attrib, value))
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		self.poll_interval = 50
		self.poll_enabled = True
		if self.instance:
			pngname = ''
			if what[0] != self.CHANGED_CLEAR:
				sname = self.source.text
				sname = sname.upper().replace('.', '').replace('\xc2\xb0', '')
				fields = sname.upper().replace('.', '').replace('\xc2\xb0', '').split(':', 10)[:10]
				if sname.startswith('4097'):
					sname = sname.replace('4097', '1', 1)
				if ':' in sname:
					sname = '_'.join(sname.split(':')[:10])
				pngname = self.nameCache.get(sname, '')
				if pngname == '' and len(fields) >= 10:
					if not fields[6].endswith("0000"):  # remove "sub-network" from namespace
						fields[6] = fields[6][:-4] + "0000"
						sname2 = '_'.join(fields)
						pngname = self.findPicon(sname2)
				if pngname == '':
					pngname = self.findPicon(sname)
					if pngname != '':
						self.nameCache[sname] = pngname

			if pngname == '':
				pngname = self.nameCache.get('default', '')
				if pngname == '':
					pngname = self.findPicon('picon_default')
					if pngname == '':
						tmp = resolveFilename(SCOPE_CURRENT_SKIN, 'picon_default.png')
						if os.path.isfile(tmp):
							pngname = tmp
						else:
							pngname = resolveFilename(SCOPE_CURRENT_SKIN, 'skin_default/picon_default.png')
					self.nameCache['default'] = pngname

			if self.pngname != pngname:
				self.picload = ePicLoad()
				try:
					self.picload.PictureData.get().append(self.piconShow)
				except (AttributeError, TypeError):
					try:
						self.picload_conn = self.picload.PictureData.connect(self.piconShow)
					except Exception:
						pass
				scale = AVSwitch().getFramebufferScale()
				self.picload.setPara((self.instance.size().width(), self.instance.size().height(), scale[0], scale[1], False, 1, "#00000000"))
				self.picload.startDecode(pngname)
				self.pngname = pngname

	def piconShow(self, picInfo=None):
		ptr = self.picload.getData()
		if ptr is not None:
			self.instance.setPixmap(ptr)
		return

	def findPicon(self, serviceName):
		for path in self.searchPaths:
			pngname = (((path % self.path) + serviceName) + '.png')
			if fileExists(pngname):
				return pngname
		return ''