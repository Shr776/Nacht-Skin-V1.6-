# -*- coding: utf-8 -*-
# PiconUni
# Copyright (c) 2boom 2012-15
# Python 3.13 port: 2026
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# 26.09.2012 added search mountpoints
# 25.06.2013 added resize picon
# 26.11.2013 code optimization
# 02.12.2013 added compatibility with CaidInfo2 (SatName)
# 18.12.2013 added picon miltipath
# 27.12.2013 added picon reference
# 27.01.2014 added noscale parameter
# 28.01.2014 code optimization
# 02.04.2014 added iptv ref code
# 17.04.2014 added path in plugin dir
# 02.07.2014 small fix reference
# 09.01.2015 redesign code

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, ePicLoad
from Components.AVSwitch import AVSwitch
from Tools.Directories import SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, SCOPE_PLUGINS, resolveFilename
import os

searchPaths = []


def initPiconPaths():
	global searchPaths
	searchPaths = []
	if os.path.isfile('/proc/mounts'):
		for line in open('/proc/mounts'):
			if '/dev/sd' in line:
				piconPath = line.split()[1].replace('\\040', ' ') + '/%s/'
				searchPaths.append(piconPath)
	searchPaths.append(resolveFilename(SCOPE_CURRENT_SKIN, '%s/'))
	searchPaths.append(resolveFilename(SCOPE_PLUGINS, '%s/'))


class PiconUniShr(Renderer):
	__module__ = __name__

	def __init__(self):
		Renderer.__init__(self)
		self.path = 'piconUni'
		self.scale = '0'
		self.nameCache = {}
		self.pngname = ''
		self.picload = None

	def applySkin(self, desktop, parent):
		attribs = []
		for (attrib, value,) in self.skinAttributes:
			if attrib == 'path':
				self.path = value
			else:
				attribs.append((attrib, value))
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		if self.instance:
			pngname = ''
			if what[0] != self.CHANGED_CLEAR:
				sname = self.source.text
				sname = sname.upper().replace('.', '').replace('\xc2\xb0', '')
				if sname.startswith('4097'):
					sname = sname.replace('4097', '1', 1)
				if ':' in sname:
					sname = '_'.join(sname.split(':')[:10])
				pngname = self.nameCache.get(sname, '')
				if pngname == '':
					pngname = self.findPicon(sname)
					if pngname != '':
						self.nameCache[sname] = pngname
			if pngname == '':
				pngname = self.nameCache.get('default', '')
				if pngname == '':
					pngname = self.findPicon('picon_default')
					if pngname == '':
						tmp = resolveFilename(SCOPE_CURRENT_SKIN, 'picon_default.png')
						if os.path.isfile(tmp):
							pngname = tmp
						else:
							pngname = resolveFilename(SCOPE_SKIN_IMAGE, 'skin_default/picon_default.png')
					self.nameCache['default'] = pngname

			if self.pngname != pngname:
				self.picload = ePicLoad()
				try:
					self.picload.PictureData.get().append(self.piconShow)
				except (AttributeError, TypeError):
					try:
						self.picload_conn = self.picload.PictureData.connect(self.piconShow)
					except Exception:
						pass
				scale = AVSwitch().getFramebufferScale()
				# 0=Width 1=Height 2=Aspect 3=use_cache 4=resize_type 5=Background(#AARRGGBB)
				self.picload.setPara((self.instance.size().width(), self.instance.size().height(), scale[0], scale[1], False, 1, "#00000000"))
				self.picload.startDecode(pngname)
				self.pngname = pngname

	def piconShow(self, picInfo=None):
		ptr = self.picload.getData()
		if ptr is not None:
			self.instance.setPixmap(ptr)
		return

	def findPicon(self, serviceName):
		global searchPaths
		pathtmp = self.path.split(',')
		for path in searchPaths:
			for dirName in pathtmp:
				pngname = (path % dirName) + serviceName + '.png'
				if os.path.isfile(pngname):
					return pngname
		return ''


initPiconPaths()