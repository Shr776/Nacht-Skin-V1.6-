# -*- coding: utf-8 -*-
# by digiteng...10.2020
# Python 3.13 port: 2026
# <widget render="Prmtm" source="ServiceEvent" position="0,0" size="700,30" font="Regular; 22" zPosition="2" transparent="1" />

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eEPGCache, eLabel
from time import localtime
from Components.config import config


class NachtPrmtm(Renderer, VariableText):
	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)
		self.epgcache = eEPGCache.getInstance()

	GUI_WIDGET = eLabel

	def changed(self, what):
		self.text = ''
		try:
			primetimehour = config.epgselection.graph_primetimehour.value
			primetimemins = config.epgselection.graph_primetimemins.value
			ref = self.source.service
			events = self.epgcache.lookupEvent(['IBDCT', (ref.toString(), 0, -1, -1)])
			if events:
				i = 0
				while True:
					i += 1
					if i >= len(events):
						break
					evnt = events[i][4]
					bt = localtime(events[i][1])
					pt = bt[3]
					duration = events[i][2] // 60
					if duration >= primetimemins and pt == primetimehour:
						today = localtime().tm_mday
						eventday = bt.tm_mday
						if today == eventday:
							self.text = self.text + "%02d:%02d - %s" % (bt[3], bt[4], evnt)
						break
		except Exception:
			return ""