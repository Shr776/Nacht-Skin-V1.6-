# -*- coding: utf-8 -*-
# MyEtEventName - Converter
# Python 3.13 port: 2026

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached


class MyEtEventNameShr(Converter, object):
	NAME = 0
	SHORT_DESCRIPTION = 1
	EXTENDED_DESCRIPTION = 2
	ID = 3
	FULL_DESCRIPTION = 3
	ID = 4

	def __init__(self, type):
		Converter.__init__(self, type)
		if type == "Description":
			self.type = self.SHORT_DESCRIPTION
		elif type == "ExtendedDescription":
			self.type = self.EXTENDED_DESCRIPTION
		elif type == "FullDescription":
			self.type = self.FULL_DESCRIPTION
		elif type == "ID":
			self.type = self.ID
		else:
			self.type = self.NAME

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return "  Join Us ............. @VuSolo."

		if self.type == self.NAME:
			if event.getEventName()[:31] == "Visibile gratis su tv terrestre":
				return event.getShortDescription().title()
			else:
				return event.getEventName()
		elif self.type == self.SHORT_DESCRIPTION:
			return event.getShortDescription()
		elif self.type == self.EXTENDED_DESCRIPTION:
			return event.getExtendedDescription()
		elif self.type == self.FULL_DESCRIPTION:
			desc = event.getShortDescription()
			if desc:
				desc = "%s\n\n" % (desc,)
			desc = "%s%s" % (desc, event.getExtendedDescription())
			return desc
		elif self.type == self.ID:
			return str(event.getEventId())

	text = property(getText)