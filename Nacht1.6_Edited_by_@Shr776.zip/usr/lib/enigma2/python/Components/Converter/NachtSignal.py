# -*- coding: utf-8 -*-
# by digiteng...10.2020
# Python 3.13 port: 2026

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached


class NachtSignal(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		if self.type == "SNR":
			sr = self.source.snr
			if sr:
				return "{}".format(sr * 100 // 65536)
			else:
				return "0"
		elif self.type == "AGC":
			ac = self.source.agc
			if ac:
				return "{}".format(ac * 100 // 65536)
			else:
				return "0"
		elif self.type == "BER":
			br = self.source.ber
			if br:
				return str(br)
			else:
				return "0"

	text = property(getText)

	@cached
	def getBool(self):
		if self.type == "BER":
			ber = self.source.ber
			if ber:
				return True
			else:
				return False
		if self.type == "LOCK":
			lock = self.source.lock
			if lock:
				return True
			else:
				return False

	boolean = property(getBool)