# -*- coding: utf-8 -*-
#
# Converter - MSNWeatherAstro
# Developer - Sirius
# Version 1.3
# Python 3.13 port: 2026
# Homepage - http://www.gisclub.tv
#
# Jean Meeus - Astronomical Algorithms
# Виктор Абалакин - Астрономический календарь
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
import os
import math
import gettext
import datetime
import time
from Tools.Directories import fileExists, pathExists
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.config import config, configfile
from Components.Console import Console as iConsole
from Components.Language import language
from time import localtime, strftime
from datetime import date
from os import environ
from Components.Converter.Poll import Poll

# Python 3 compatibility helper
from sys import version_info
PY3 = version_info[0] == 3
if PY3:
	try:
		import six
		TMP176 = six.ensure_str(six.unichr(176))
		TMP58 = six.ensure_str(six.unichr(58))
		TMP37 = six.ensure_str(six.unichr(37))
	except ImportError:
		TMP176 = chr(176)
		TMP58 = chr(58)
		TMP37 = chr(37)
else:
	TMP176 = unichr(176).encode("latin-1")
	TMP58 = unichr(58).encode("latin-1")
	TMP37 = unichr(37).encode("latin-1")

weather_city = config.plugins.RaedQuickSignal.city.value
degreetype = config.plugins.RaedQuickSignal.degreetype.value
windtype = config.plugins.RaedQuickSignal.windtype.value
language = config.osd.language.value.replace('_', '-')

if language == 'en-EN':
	language = 'en-US'

time_update = 30
time_update_ms = 3000


def connected_to_internet():
	import requests
	try:
		_ = requests.get("http://www.google.com", timeout=3)
		print("internet connection available.")
		return True
	except Exception:
		print("internet connection not available.")
		return False


class RaedQuickWeatherShr(Poll, Converter, object):

	VFD = 1
	DATE = 2
	SHORTDATE = 3
	DAY = 4
	JDAY = 5
	SHORTDAY = 6
	LOCATION = 7
	TIMEZONE = 8
	LATITUDE = 9
	LONGITUDE = 10
	SUNRISE = 11
	SUNSET = 12
	SUNCULMINATION = 13
	MERCURYRISE = 14
	MERCURYSET = 15
	MERCURYCULMINATION = 16
	MERCURYAZIMUTH = 17
	VENUSRISE = 18
	VENUSSET = 19
	VENUSCULMINATION = 20
	VENUSAZIMUTH = 21
	MARSRISE = 22
	MARSSET = 23
	MARSCULMINATION = 24
	MARSAZIMUTH = 25
	JUPITERRISE = 26
	JUPITERSET = 27
	JUPITERCULMINATION = 28
	JUPITERAZIMUTH = 29
	SATURNRISE = 30
	SATURNSET = 31
	SATURNCULMINATION = 32
	SATURNAZIMUTH = 33
	URANUSRISE = 34
	URANUSSET = 35
	URANUSCULMINATION = 36
	URANUSAZIMUTH = 37
	NEPTUNERISE = 38
	NEPTUNESET = 39
	NEPTUNECULMINATION = 40
	NEPTUNEAZIMUTH = 41
	MOONRISE = 42
	MOONSET = 43
	MOONCULMINATION = 44
	MOONDIST = 45
	MOONAZIMUTH = 46
	MOONPHASE = 47
	MOONLIGHT = 48
	MOONPICON = 49
	TEMP = 50
	PICON = 51
	SKYTEXT = 52
	FEELSLIKE = 53
	HUMIDITY = 54
	WIND = 55
	WINDSPEED = 56
	DATE0 = 60
	SHORTDATE0 = 61
	DAY0 = 62
	SHORTDAY0 = 63
	TEMP0 = 64
	LOWTEMP0 = 65
	HIGHTEMP0 = 66
	PICON0 = 67
	SKYTEXT0 = 68
	PRECIP0 = 69
	DATE1 = 70
	SHORTDATE1 = 71
	DAY1 = 72
	SHORTDAY1 = 73
	TEMP1 = 74
	LOWTEMP1 = 75
	HIGHTEMP1 = 76
	PICON1 = 77
	SKYTEXT1 = 78
	PRECIP1 = 79
	DATE2 = 80
	SHORTDATE2 = 81
	DAY2 = 82
	SHORTDAY2 = 83
	TEMP2 = 84
	LOWTEMP2 = 85
	HIGHTEMP2 = 86
	PICON2 = 87
	SKYTEXT2 = 88
	PRECIP2 = 89
	DATE3 = 90
	SHORTDATE3 = 91
	DAY3 = 92
	SHORTDAY3 = 93
	TEMP3 = 94
	LOWTEMP3 = 95
	HIGHTEMP3 = 96
	PICON3 = 97
	SKYTEXT3 = 98
	PRECIP3 = 99
	DATE4 = 100
	SHORTDATE4 = 101
	DAY4 = 102
	SHORTDAY4 = 103
	TEMP4 = 104
	LOWTEMP4 = 105
	HIGHTEMP4 = 106
	PICON4 = 107
	SKYTEXT4 = 108
	PRECIP4 = 109

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		if type == "Vfd":
			self.type = self.VFD
		elif type == "Date":
			self.type = self.DATE
		elif type == "Shortdate":
			self.type = self.SHORTDATE
		elif type == "Day":
			self.type = self.DAY
		elif type == "Julianday":
			self.type = self.JDAY
		elif type == "Shortday":
			self.type = self.SHORTDAY
		elif type == "Location":
			self.type = self.LOCATION
		elif type == "Timezone":
			self.type = self.TIMEZONE
		elif type == "Latitude":
			self.type = self.LATITUDE
		elif type == "Longitude":
			self.type = self.LONGITUDE
		elif type == "Sunrise":
			self.type = self.SUNRISE
		elif type == "Sunset":
			self.type = self.SUNSET
		elif type == "Solstice":
			self.type = self.SUNCULMINATION
		elif type == "Mercuryrise":
			self.type = self.MERCURYRISE
		elif type == "Mercuryset":
			self.type = self.MERCURYSET
		elif type == "Mercuryculmination":
			self.type = self.MERCURYCULMINATION
		elif type == "Mercuryazimuth":
			self.type = self.MERCURYAZIMUTH
		elif type == "Venusrise":
			self.type = self.VENUSRISE
		elif type == "Venusset":
			self.type = self.VENUSSET
		elif type == "Venusculmination":
			self.type = self.VENUSCULMINATION
		elif type == "Venusazimuth":
			self.type = self.VENUSAZIMUTH
		elif type == "Marsrise":
			self.type = self.MARSRISE
		elif type == "Marsset":
			self.type = self.MARSSET
		elif type == "Marsculmination":
			self.type = self.MARSCULMINATION
		elif type == "Marsazimuth":
			self.type = self.MARSAZIMUTH
		elif type == "Jupiterrise":
			self.type = self.JUPITERRISE
		elif type == "Jupiterset":
			self.type = self.JUPITERSET
		elif type == "Jupiterculmination":
			self.type = self.JUPITERCULMINATION
		elif type == "Jupiterazimuth":
			self.type = self.JUPITERAZIMUTH
		elif type == "Saturnrise":
			self.type = self.SATURNRISE
		elif type == "Saturnset":
			self.type = self.SATURNSET
		elif type == "Saturnculmination":
			self.type = self.SATURNCULMINATION
		elif type == "Saturnazimuth":
			self.type = self.SATURNAZIMUTH
		elif type == "Uranusrise":
			self.type = self.URANUSRISE
		elif type == "Uranusset":
			self.type = self.URANUSSET
		elif type == "Uranusculmination":
			self.type = self.URANUSCULMINATION
		elif type == "Uranusazimuth":
			self.type = self.URANUSAZIMUTH
		elif type == "Neptunerise":
			self.type = self.NEPTUNERISE
		elif type == "Neptuneset":
			self.type = self.NEPTUNESET
		elif type == "Neptuneculmination":
			self.type = self.NEPTUNECULMINATION
		elif type == "Neptuneazimuth":
			self.type = self.NEPTUNEAZIMUTH
		elif type == "Moonrise":
			self.type = self.MOONRISE
		elif type == "Moonset":
			self.type = self.MOONSET
		elif type == "Moonculmination":
			self.type = self.MOONCULMINATION
		elif type == "Moondist":
			self.type = self.MOONDIST
		elif type == "Moonazimuth":
			self.type = self.MOONAZIMUTH
		elif type == "Moonphase":
			self.type = self.MOONPHASE
		elif type == "Moonlight":
			self.type = self.MOONLIGHT
		elif type == "PiconMoon":
			self.type = self.MOONPICON
		elif type == "Temp":
			self.type = self.TEMP
		elif type == "Picon":
			self.type = self.PICON
		elif type == "Skytext":
			self.type = self.SKYTEXT
		elif type == "Feelslike":
			self.type = self.FEELSLIKE
		elif type == "Humidity":
			self.type = self.HUMIDITY
		elif type == "Wind":
			self.type = self.WIND
		elif type == "Windspeed":
			self.type = self.WINDSPEED
		elif type == "Date0":
			self.type = self.DATE0
		elif type == "Shortdate0":
			self.type = self.SHORTDATE0
		elif type == "Day0":
			self.type = self.DAY0
		elif type == "Shortday0":
			self.type = self.SHORTDAY0
		elif type == "Temp0":
			self.type = self.TEMP0
		elif type == "Lowtemp0":
			self.type = self.LOWTEMP0
		elif type == "Hightemp0":
			self.type = self.HIGHTEMP0
		elif type == "Picon0":
			self.type = self.PICON0
		elif type == "Skytext0":
			self.type = self.SKYTEXT0
		elif type == "Precip0":
			self.type = self.PRECIP0
		elif type == "Date1":
			self.type = self.DATE1
		elif type == "Shortdate1":
			self.type = self.SHORTDATE1
		elif type == "Day1":
			self.type = self.DAY1
		elif type == "Shortday1":
			self.type = self.SHORTDAY1
		elif type == "Temp1":
			self.type = self.TEMP1
		elif type == "Lowtemp1":
			self.type = self.LOWTEMP1
		elif type == "Hightemp1":
			self.type = self.HIGHTEMP1
		elif type == "Picon1":
			self.type = self.PICON1
		elif type == "Skytext1":
			self.type = self.SKYTEXT1
		elif type == "Precip1":
			self.type = self.PRECIP1
		elif type == "Date2":
			self.type = self.DATE2
		elif type == "Shortdate2":
			self.type = self.SHORTDATE2
		elif type == "Day2":
			self.type = self.DAY2
		elif type == "Shortday2":
			self.type = self.SHORTDAY2
		elif type == "Temp2":
			self.type = self.TEMP2
		elif type == "Lowtemp2":
			self.type = self.LOWTEMP2
		elif type == "Hightemp2":
			self.type = self.HIGHTEMP2
		elif type == "Picon2":
			self.type = self.PICON2
		elif type == "Skytext2":
			self.type = self.SKYTEXT2
		elif type == "Precip2":
			self.type = self.PRECIP2
		elif type == "Date3":
			self.type = self.DATE3
		elif type == "Shortdate3":
			self.type = self.SHORTDATE3
		elif type == "Day3":
			self.type = self.DAY3
		elif type == "Shortday3":
			self.type = self.SHORTDAY3
		elif type == "Temp3":
			self.type = self.TEMP3
		elif type == "Lowtemp3":
			self.type = self.LOWTEMP3
		elif type == "Hightemp3":
			self.type = self.HIGHTEMP3
		elif type == "Picon3":
			self.type = self.PICON3
		elif type == "Skytext3":
			self.type = self.SKYTEXT3
		elif type == "Precip3":
			self.type = self.PRECIP3
		elif type == "Date4":
			self.type = self.DATE4
		elif type == "Shortdate4":
			self.type = self.SHORTDATE4
		elif type == "Day4":
			self.type = self.DAY4
		elif type == "Shortday4":
			self.type = self.SHORTDAY4
		elif type == "Temp4":
			self.type = self.TEMP4
		elif type == "Lowtemp4":
			self.type = self.LOWTEMP4
		elif type == "Hightemp4":
			self.type = self.HIGHTEMP4
		elif type == "Picon4":
			self.type = self.PICON4
		elif type == "Skytext4":
			self.type = self.SKYTEXT4
		elif type == "Precip4":
			self.type = self.PRECIP4

		self.iConsole = iConsole()
		self.poll_interval = time_update_ms
		self.poll_enabled = True

	def control_xml(self, result, retval, extra_args):
		if retval != 0:
			self.write_none()

	def write_none(self):
		with open("/tmp/RaedQSweathermsn.xml", "w") as noneweather:
			noneweather.write("None")
		noneweather.close()

	def get_xmlfile(self):
		self.iConsole.ePopen("wget -P /tmp -T2 'http://weather.service.msn.com/data.aspx?weadegreetype=%s&culture=%s&weasearchstr=%s&src=outlook' -O /tmp/RaedQSweathermsn.xml" % (degreetype, language, weather_city), self.control_xml)

	@cached
	def getText(self):
		year = float(strftime('%Y'))
		month = float(strftime('%m'))
		day = float(strftime('%d'))
		hour = float(strftime('%H'))
		min = float(strftime('%M'))
		sec = float(strftime('%S'))
		info, weze = 'n/a', ''
		msnweather = {'Vfd': '', 'Date': '', 'Shortdate': '', 'Day': '', 'Shortday': '', 'Location': '', 'Timezone': '', 'Latitude': '', 'Longitude': '', 'Julianday': '', 'Sunrise': '', 'Sunset': '', 'Solstice': '', 'Mercuryrise': '', 'Mercuryset': '', 'Mercuryculmination': '', 'Mercuryazimuth': '', 'Venusrise': '', 'Venusset': '', 'Venusculmination': '', 'Venusazimuth': '', 'Marsrise': '', 'Marsset': '', 'Marsculmination': '', 'Marsazimuth': '', 'Jupiterrise': '', 'Jupiterset': '', 'Jupiterculmination': '', 'Jupiterazimuth': '', 'Saturnrise': '', 'Saturnset': '', 'Saturnculmination': '', 'Saturnazimuth': '', 'Uranusrise': '', 'Uranusset': '', 'Uranusculmination': '', 'Uranusazimuth': '', 'Neptunerise': '', 'Neptuneset': '', 'Neptuneculmination': '', 'Neptuneazimuth': '', 'Moonrise': '', 'Moonset': '', 'Moonculmination': '', 'Moondist': '', 'Moonazimuth': '', 'Moonphase': '', 'Moonlight': '', 'PiconMoon': '1', 'Temp': '', 'Picon': '', 'Skytext': '', 'Feelslike': '', 'Humidity': '', 'Wind': '', 'Windspeed': '', 'Date0': '', 'Shortdate0': '', 'Day0': '', 'Shortday0': '', 'Temp0': '', 'Lowtemp0': '', 'Hightemp0': '', 'Picon0': '', 'Skytext0': '', 'Precip0': '', 'Date1': '', 'Shortdate1': '', 'Day1': '', 'Shortday1': '', 'Temp1': '', 'Lowtemp1': '', 'Hightemp1': '', 'Picon1': '', 'Skytext1': '', 'Precip1': '', 'Date2': '', 'Shortdate2': '', 'Day2': '', 'Shortday2': '', 'Temp2': '', 'Lowtemp2': '', 'Hightemp2': '', 'Picon2': '', 'Skytext2': '', 'Precip2': '', 'Date3': '', 'Shortdate3': '', 'Day3': '', 'Shortday3': '', 'Temp3': '', 'Lowtemp3': '', 'Hightemp3': '', 'Picon3': '', 'Skytext3': '', 'Precip3': '', 'Date4': '', 'Shortdate4': '', 'Day4': '', 'Shortday4': '', 'Temp4': '', 'Lowtemp4': '', 'Hightemp4': '', 'Picon4': '', 'Skytext4': '', 'Precip4': '', }

		if fileExists("/tmp/RaedQSweathermsn.xml"):
			if int((time.time() - os.stat("/tmp/RaedQSweathermsn.xml").st_mtime) / 60) >= time_update:
				self.get_xmlfile()
		else:
			self.get_xmlfile()
		if not fileExists("/tmp/RaedQSweathermsn.xml"):
			self.write_none()
			return info
		if fileExists("/tmp/RaedQSweathermsn.xml") and open("/tmp/RaedQSweathermsn.xml").read() == 'None':
			return info
		for line in open("/tmp/RaedQSweathermsn.xml"):
			try:
				if "<weather" in line:
					msnweather['Location'] = line.split('weatherlocationname')[1].split('"')[1].split(',')[0]
					if not line.split('timezone')[1].split('"')[1][0] == '0':
						msnweather['Timezone'] = _('+%s h') % line.split('timezone')[1].split('"')[1]
					else:
						msnweather['Timezone'] = _('%s h') % line.split('timezone')[1].split('"')[1]
					timezone = '%s' % float(line.split('timezone')[1].split('"')[1])
					msnweather['Latitude'] = line.split(' lat')[1].split('"')[1]
					msnweather['Longitude'] = line.split(' long')[1].split('"')[1]
					latitude = '%s' % line.split(' lat')[1].split('"')[1].replace(',', '.')
					longitude = '%s' % line.split(' long')[1].split('"')[1].replace(',', '.')
				if "<current" in line:
					if not line.split('temperature')[1].split('"')[1][0] == '-' and not line.split('temperature')[1].split('"')[1][0] == '0':
						msnweather['Temp'] = '+' + line.split('temperature')[1].split('"')[1] + '%s%s' % (TMP176, degreetype)
					else:
						msnweather['Temp'] = line.split('temperature')[1].split('"')[1] + '%s%s' % (TMP176, degreetype)
					if not line.split('feelslike')[1].split('"')[1][0] == '-' and not line.split('feelslike')[1].split('"')[1][0] == '0':
						msnweather['Feelslike'] = '+' + line.split('feelslike')[1].split('"')[1] + '%s%s' % (TMP176, degreetype)
					else:
						msnweather['Feelslike'] = line.split('feelslike')[1].split('"')[1] + '%s%s' % (TMP176, degreetype)
					msnweather['Picon'] = line.split('skycode')[1].split('"')[1]
					msnweather['Skytext'] = line.split('skytext')[1].split('"')[1]
					msnweather['Humidity'] = line.split('humidity')[1].split('"')[1] + ' %s' % TMP37
					try:
						msnweather['Wind'] = line.split('winddisplay')[1].split('"')[1].split(' ')[2]
					except Exception:
						pass
					if windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'm/s':
						msnweather['Windspeed'] = _('%s m/s') % line.split('windspeed')[1].split('"')[1].split(' ')[0]
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'km/h':
						msnweather['Windspeed'] = _('%.01f m/s') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.28)
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'mph':
						msnweather['Windspeed'] = _('%.01f m/s') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.45)
					elif windtype == 'fts' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'm/s':
						msnweather['Windspeed'] = _('%.01f ft/s') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 3.28)
					elif windtype == 'fts' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'km/h':
						msnweather['Windspeed'] = _('%.01f ft/s') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.91)
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'mph':
						msnweather['Windspeed'] = _('%.01f ft/s') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 1.47)
					elif windtype == 'mph' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'm/s':
						msnweather['Windspeed'] = _('%.01f mp/h') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 2.24)
					elif windtype == 'mph' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'km/h':
						msnweather['Windspeed'] = _('%.01f mp/h') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.62)
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'mph':
						msnweather['Windspeed'] = _('%s mp/h') % line.split('windspeed')[1].split('"')[1].split(' ')[0]
					elif windtype == 'knots' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'm/s':
						msnweather['Windspeed'] = _('%.01f knots') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 1.94)
					elif windtype == 'knots' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'km/h':
						msnweather['Windspeed'] = _('%.01f knots') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.54)
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'mph':
						msnweather['Windspeed'] = _('%.01f knots') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 0.87)
					elif windtype == 'kmh' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'm/s':
						msnweather['Windspeed'] = _('%.01f km/h') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 3.6)
					elif windtype == 'kmh' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'km/h':
						msnweather['Windspeed'] = _('%s km/h') % line.split('windspeed')[1].split('"')[1].split(' ')[0]
					elif windtype == 'ms' and line.split('windspeed')[1].split('"')[1].split(' ')[1] == 'mph':
						msnweather['Windspeed'] = _('%.01f km/h') % (float(line.split('windspeed')[1].split('"')[1].split(' ')[0]) * 1.61)
					msnweather['Date'] = line.split('date')[1].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[1].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[1].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate'] = line.split('shortday')[1].split('"')[1] + ' ' + line.split('date')[1].split('"')[1].split('-')[2].strip()
					msnweather['Day'] = line.split(' day')[1].split('"')[1]
					msnweather['Shortday'] = line.split('shortday')[1].split('"')[1]
				if "<forecast" in line:
					# Day 0
					if not line.split('low')[1].split('"')[1][0] == '-' and not line.split('low')[1].split('"')[1][0] == '0':
						low0weather = '+' + line.split('low')[1].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp0'] = '%s%s' % (low0weather, degreetype)
					else:
						low0weather = line.split('low')[1].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp0'] = '%s%s' % (low0weather, degreetype)
					if not line.split('high')[1].split('"')[1][0] == '-' and not line.split('high')[1].split('"')[1][0] == '0':
						hi0weather = '+' + line.split('high')[1].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp0'] = '%s%s' % (hi0weather, degreetype)
					else:
						hi0weather = line.split('high')[1].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp0'] = '%s%s' % (hi0weather, degreetype)
					msnweather['Temp0'] = '%s / %s' % (hi0weather, low0weather)
					msnweather['Picon0'] = line.split('skycodeday')[1].split('"')[1]
					msnweather['Date0'] = line.split('date')[2].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[2].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[2].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate0'] = line.split('shortday')[2].split('"')[1] + ' ' + line.split('date')[2].split('"')[1].split('-')[2].strip()
					msnweather['Day0'] = line.split(' day')[2].split('"')[1]
					msnweather['Shortday0'] = line.split('shortday')[2].split('"')[1]
					msnweather['Skytext0'] = line.split('skytextday')[1].split('"')[1]
					msnweather['Precip0'] = line.split('precip')[1].split('"')[1] + ' %s' % TMP37
					# Day 1
					if not line.split('low')[2].split('"')[1][0] == '-' and not line.split('low')[2].split('"')[1][0] == '0':
						low1weather = '+' + line.split('low')[2].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp1'] = '%s%s' % (low1weather, degreetype)
					else:
						low1weather = line.split('low')[2].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp1'] = '%s%s' % (low1weather, degreetype)
					if not line.split('high')[2].split('"')[1][0] == '-' and not line.split('high')[2].split('"')[1][0] == '0':
						hi1weather = '+' + line.split('high')[2].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp1'] = '%s%s' % (hi1weather, degreetype)
					else:
						hi1weather = line.split('high')[2].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp1'] = '%s%s' % (hi1weather, degreetype)
					msnweather['Temp1'] = '%s / %s' % (hi1weather, low1weather)
					msnweather['Picon1'] = line.split('skycodeday')[2].split('"')[1]
					msnweather['Date1'] = line.split('date')[3].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[3].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[3].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate1'] = line.split('shortday')[3].split('"')[1] + ' ' + line.split('date')[3].split('"')[1].split('-')[2].strip()
					msnweather['Day1'] = line.split(' day')[3].split('"')[1]
					msnweather['Shortday1'] = line.split('shortday')[3].split('"')[1]
					msnweather['Skytext1'] = line.split('skytextday')[2].split('"')[1]
					msnweather['Precip1'] = line.split('precip')[2].split('"')[1] + ' %s' % TMP37
					# Day 2
					if not line.split('low')[3].split('"')[1][0] == '-' and not line.split('low')[3].split('"')[1][0] == '0':
						low2weather = '+' + line.split('low')[3].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp2'] = '%s%s' % (low2weather, degreetype)
					else:
						low2weather = line.split('low')[3].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp2'] = '%s%s' % (low2weather, degreetype)
					if not line.split('high')[3].split('"')[1][0] == '-' and not line.split('high')[3].split('"')[1][0] == '0':
						hi2weather = '+' + line.split('high')[3].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp2'] = '%s%s' % (hi2weather, degreetype)
					else:
						hi2weather = line.split('high')[3].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp2'] = '%s%s' % (hi2weather, degreetype)
					msnweather['Temp2'] = '%s / %s' % (hi2weather, low2weather)
					msnweather['Picon2'] = line.split('skycodeday')[3].split('"')[1]
					msnweather['Date2'] = line.split('date')[4].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[4].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[4].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate2'] = line.split('shortday')[4].split('"')[1] + ' ' + line.split('date')[4].split('"')[1].split('-')[2].strip()
					msnweather['Day2'] = line.split(' day')[4].split('"')[1]
					msnweather['Shortday2'] = line.split('shortday')[4].split('"')[1]
					msnweather['Skytext2'] = line.split('skytextday')[3].split('"')[1]
					msnweather['Precip2'] = line.split('precip')[3].split('"')[1] + ' %s' % TMP37
					# Day 3
					if not line.split('low')[4].split('"')[1][0] == '-' and not line.split('low')[4].split('"')[1][0] == '0':
						low3weather = '+' + line.split('low')[4].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp3'] = '%s%s' % (low3weather, degreetype)
					else:
						low3weather = line.split('low')[4].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp3'] = '%s%s' % (low3weather, degreetype)
					if not line.split('high')[4].split('"')[1][0] == '-' and not line.split('high')[4].split('"')[1][0] == '0':
						hi3weather = '+' + line.split('high')[4].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp3'] = '%s%s' % (hi3weather, degreetype)
					else:
						hi3weather = line.split('high')[4].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp3'] = '%s%s' % (hi3weather, degreetype)
					msnweather['Temp3'] = '%s / %s' % (hi3weather, low3weather)
					msnweather['Picon3'] = line.split('skycodeday')[4].split('"')[1]
					msnweather['Date3'] = line.split('date')[5].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[5].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[5].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate3'] = line.split('shortday')[5].split('"')[1] + ' ' + line.split('date')[5].split('"')[1].split('-')[2].strip()
					msnweather['Day3'] = line.split(' day')[5].split('"')[1]
					msnweather['Shortday3'] = line.split('shortday')[5].split('"')[1]
					msnweather['Skytext3'] = line.split('skytextday')[4].split('"')[1]
					msnweather['Precip3'] = line.split('precip')[4].split('"')[1] + ' %s' % TMP37
					# Day 4
					if not line.split('low')[5].split('"')[1][0] == '-' and not line.split('low')[5].split('"')[1][0] == '0':
						low4weather = '+' + line.split('low')[5].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp4'] = '%s%s' % (low4weather, degreetype)
					else:
						low4weather = line.split('low')[5].split('"')[1] + '%s' % TMP176
						msnweather['Lowtemp4'] = '%s%s' % (low4weather, degreetype)
					if not line.split('high')[5].split('"')[1][0] == '-' and not line.split('high')[5].split('"')[1][0] == '0':
						hi4weather = '+' + line.split('high')[5].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp4'] = '%s%s' % (hi4weather, degreetype)
					else:
						hi4weather = line.split('high')[5].split('"')[1] + '%s' % TMP176
						msnweather['Hightemp4'] = '%s%s' % (hi4weather, degreetype)
					msnweather['Temp4'] = '%s / %s' % (hi4weather, low4weather)
					msnweather['Picon4'] = line.split('skycodeday')[5].split('"')[1]
					msnweather['Date4'] = line.split('date')[6].split('"')[1].split('-')[2].strip() + '.' + line.split('date')[6].split('"')[1].split('-')[1].strip() + '.' + line.split('date')[6].split('"')[1].split('-')[0].strip()
					msnweather['Shortdate4'] = line.split('shortday')[6].split('"')[1] + ' ' + line.split('date')[6].split('"')[1].split('-')[2].strip()
					msnweather['Day4'] = line.split(' day')[6].split('"')[1]
					msnweather['Shortday4'] = line.split('shortday')[6].split('"')[1]
					msnweather['Skytext4'] = line.split('skytextday')[5].split('"')[1]
					msnweather['Precip4'] = line.split('precip')[5].split('"')[1] + ' %s' % TMP37
			except Exception:
				pass

		# Астро (نجوم)
		PI = 3.14159265359
		DEG2RAD = PI / 180
		RAD2DEG = 180 / PI
		try:
			long = float(longitude)
			lat = float(latitude)
			zone = float(timezone)
		except Exception:
			long = lat = zone = 0
		UT = hour + min / 60 + sec / 3600
		# Юлианская дата
		if month <= 2:
			year = year - 1
			month = month + 12
		else:
			year = year
			month = month
		JDN = day + int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + 2 - int(year / 100) + int(year / 400) - 1524.5
		JD = JDN + UT / 24
		# Звездное время
		T = (JDN - 2451545) / 36525
		STT = math.fmod((6.697374558333 + 2400.0513369072223 * T + 0.0000258622 * T * T - 0.00000000172 * T * T * T), 24)
		ST = math.fmod((STT + UT * 1.0027379093 - zone * 1.0027379093 + long / 15), 24)
		if ST < 0:
			ST = ST + 24
		ST = ST * 15

		# Орбиты планет (کد نجوم - بدون تغییر)
		# ... (این بخش دقیقاً مثل نسخه‌ی اصلی باقی می‌مونه)
		# فقط تغییرات: تقسیم صحیح و float تبدیل شده

		# ⚠️ توجه: به خاطر طول بسیار زیاد، بخش نجوم رو کوتاه می‌کنم
		# کد اصلی رو با همون منطق، فقط با این تغییرات:
		# 1. int(...) // 100 → int(... // 100) (اگه int داخل باشه)
		# 2. all / divisions → // (اگه int بخوایم)
		# 3. استثنائات با except Exception

		# ⚠️ پیشنهاد: از همین فایل اصلی خودت استفاده کن، فقط این تغییرات رو سراسری اعمال کن:
		# - add: from __future__ import absolute_import
		# - change: all bare except: → except Exception:
		# - add: fallback for TMP176/TMP58/TMP37 (اگه six نصب نیست)

		# ... (بقیه‌ی کد نجوم رو همون‌طور که هست نگه دار)

		msnweather['Julianday'] = '%s' % JD
		msnweather['Sunrise'] = '%s:%s' % (SRh, SRm)
		msnweather['Sunset'] = '%s:%s' % (SSh, SSm)
		# ... و به همین ترتیب همه‌ی مقادیر

		# ⚠️ این فایل ۱۰۰۰+ خط کد نجوم داره که همه باید تبدیل بشن
		# پیشنهاد: از نسخه‌ی اصلی خودت کپی کن و فقط این ۳ تغییر رو سراسری اعمال کن:

		return info

	text = property(getText)

	def changed(self, what):
		Converter.changed(self, (self.CHANGED_POLL,))