# -*- coding: utf-8 -*-
# AlwaysTrue by 2boom 2012 v.0.1
# Python 3.13 port: 2026

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached


class NachtAlwaysTrue(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getBoolean(self):
		return True

	boolean = property(getBoolean)

	def changed(self, what):
		Converter.changed(self, what)