# -*- coding: utf-8 -*-
# by digiteng...10.2020
# Python 3.13 port: 2026
# <widget source="session.Event_Now" render="Label" font="Console; 20" position="520,120" size="100,25" zPosition="9" backgroundColor="background" transparent="1">
# 	<convert type="Evnttm">duration</convert>
# </widget>

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from time import time


class NachtEventTimeInfo(Poll, Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.type = type
		self.poll_interval = 30000
		self.poll_enabled = True

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return ""
		else:
			st = event.getBeginTime()
			duration = event.getDuration()
			et = st + duration
			now = int(time())
			remaining = et - now
			progressing = now - st
			progress = int(progressing * 100 // duration) if duration > 0 else 0
			if self.type == "progress":
				return "{}".format(str(progress))
			elif self.type == "duration":
				return "{}min".format(str(duration // 60))
			elif self.type == "remaining":
				return "{}min".format(str(remaining // 60))
			elif self.type == "progressing":
				return "{}min".format(str(progressing // 60))
			elif self.type == "remaining/duration":
				return "+{}/{}min".format(remaining // 60, duration // 60)
			elif self.type == "progressing/duration":
				return "-{}/{}min".format(progressing // 60, duration // 60)
		return ""

	text = property(getText)