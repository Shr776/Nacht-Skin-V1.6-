# -*- coding: utf-8 -*-
# by digiteng...10.2020
# Python 3.13 port: 2026

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached


class NachtEventInfo(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		event = self.source.event
		if event:
			if self.type == "name":
				return event.getEventName()
			if self.type == "short-description":
				return event.getShortDescription()
			if self.type == "extended-description":
				return event.getExtendedDescription()
			if self.type == "full-description":
				return "{}\n{}".format(event.getShortDescription(), event.getExtendedDescription())
		else:
			return ""

	text = property(getText)