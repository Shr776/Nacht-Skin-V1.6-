# -*- coding: utf-8 -*-
# by digiteng...09.2020
# Python 3.13 port: 2026
# <widget source='session.Event_Now' render='Label' position='135,80' size='330,40' font='Regular; 14' halign='left' transparent='1' zPosition='2' backgroundColor='background' valign='center'>
# 	<convert type='EvntInfo'>SESSION_EPISODE,PARENTAL_RATING,YEAR,GENRE,DURATION</convert>
# </widget>

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.NachtEventGenre import getGenreStringSub
import re


class NachtEventInfo2(Converter, object):

	SESSION_EPISODE = 'SESSION_EPISODE'
	PARENTAL_RATING = 'PARENTAL_RATING'
	YEAR = 'YEAR'
	DURATION = 'DURATION'
	GENRE = 'GENRE'

	def __init__(self, type):
		Converter.__init__(self, type)
		self.types = str(type).split(',')

	@cached
	def getText(self):
		event = self.source.event
		if event:
			fd = event.getEventName() + '\n' + event.getShortDescription() + '\n' + event.getExtendedDescription()
			if self.types:
				eventList = []
				try:
					for type in self.types:
						type.strip()

						if type == self.SESSION_EPISODE:
							prs = [r'(\d+). Staffel, Folge (\d+)', r'T(\d+) Ep.(\d+)', r'"Episodio (\d+)" T(\d+)']
							for i in prs:
								seg = re.search(i, fd)
								if seg:
									s = seg.group(1).zfill(2)
									e = seg.group(2).zfill(2)
									se = 'S%sE%s' % (s, e)
									eventList.append(str(se))

						elif type == self.PARENTAL_RATING:
							parentName = ''
							prs = [r'[aA]b ((\d+))', r'[+]((\d+))', r'Od lat: ((\d+))', r'(\d+)[+]', r'(TP)', r'[-](\d+)']
							for i in prs:
								prr = re.search(i, fd)
								if prr:
									parentName = prr.group(1)
									parentName = parentName.replace('7', '6').replace('10', '12').replace('TP', '0')
									eventList.append('+' + str(parentName))
									break
							age = ''
							country = ''
							rating = event.getParentalData()
							if rating:
								country = rating.getCountryCode().upper()
								if parentName == '':
									age = rating.getRating()
									eventList.append('+{}({})'.format(str(age), str(country)))

						elif type == self.YEAR:
							year = ''
							fd = fd.replace(',', '').replace('(', '').replace(')', '')
							fdl = [r'\d{4} [A-Z]+', r'[A-Z]+ \d{4}', r'[A-Z][a-z]+\s\d{4}', r'\+\d+\s\d{4}']
							for i in fdl:
								year = re.findall(i, fd)
								if year:
									year = re.sub(r'\(.*?\)|\.|\+\d+', ' ', year[0]).strip()
									eventList.append(str(year))
									break

						elif type == self.DURATION:
							drtn = event.getDuration() // 60
							if drtn > 0:
								eventList.append('{} min'.format(drtn))
							else:
								prs = re.findall(r' \d+ Min', fd)
								if prs:
									drtn = str(prs[0]).strip()
									eventList.append(str(drtn))

						elif type == self.GENRE:
							genres = event.getGenreDataList()
							if genres:
								genre = genres[0]
								eventList.append(getGenreStringSub(genre[0], genre[1]))

					sep_color = '\\c0000??00' + ' | '
					sep_color += '\\c00??????'
					return sep_color.join(eventList)
				except Exception:
					return ''
		return ""

	text = property(getText)